please refer to github 
https://github.com/BoschSensortec/BSEC-Arduino-library

Latest examples are available in the release package in website, which would be updated in GitHub soon.