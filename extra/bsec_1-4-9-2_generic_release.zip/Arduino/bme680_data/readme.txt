basic_data_logging is a mere example code and illustration here still uses an old sensor API version. 
